package com.imagine.mod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.IntConsumer;

/** Small helpers shared by every ability. */
public final class Util {
    private Util() {}

    public static final String ALLY = "img_ally";
    /** Summoned allies of THIS session -> game time they expire (stale ones from old sessions get removed on load). */
    public static final Map<UUID, Long> LIVE = new HashMap<>();

    public record Target(Vec3 pos, LivingEntity entity) {}

    public static void msg(Player p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    public static boolean gone(ServerLevel sw, Player u) {
        return !u.isAlive() || u.isRemoved() || u.level() != sw;
    }

    /** Run body(0..count-1), one run every `step` ticks. */
    public static void loop(int count, int step, IntConsumer body) {
        for (int i = 0; i < count; i++) {
            final int ii = i;
            Scheduler.later(i * step + 1, () -> body.accept(ii));
        }
    }

    public static void launch(Entity e, double x, double y, double z) {
        e.setDeltaMovement(x, y, z);
        e.hurtMarked = true;
    }

    /** Knock an entity away from a point. */
    public static void shove(Entity e, Vec3 from, double power, double lift) {
        Vec3 away = e.position().subtract(from);
        away = new Vec3(away.x, 0, away.z);
        away = away.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : away.normalize();
        launch(e, away.x * power, lift, away.z * power);
    }

    /** Pull an entity toward a point. */
    public static void pull(Entity e, Vec3 to, double power) {
        Vec3 v = to.subtract(e.position().add(0, e.getBbHeight() / 2, 0));
        if (v.lengthSqr() < 0.25) return;
        v = v.normalize().scale(power);
        launch(e, v.x, v.y * 0.6 + 0.08, v.z);
    }

    public static boolean isFoe(Mob m) {
        return m instanceof Enemy && m.isAlive() && !m.getTags().contains(ALLY);
    }

    /** Hostile mobs near a point (never players, pets, villagers or our allies). */
    public static List<Mob> foes(ServerLevel sw, Vec3 c, double r) {
        return sw.getEntitiesOfClass(Mob.class, new AABB(c, c).inflate(r),
                m -> isFoe(m) && m.distanceToSqr(c) <= r * r);
    }

    public static List<ServerPlayer> playersNear(ServerLevel sw, Vec3 c, double r) {
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : sw.players()) {
            if (p.distanceToSqr(c) <= r * r) out.add(p);
        }
        return out;
    }

    public static void hurt(ServerLevel sw, Player u, LivingEntity e, float dmg) {
        e.hurt(sw.damageSources().indirectMagic(u, u), dmg);
    }

    public static void tp(Player u, double x, double y, double z) {
        if (u instanceof ServerPlayer sp) {
            sp.teleportTo(x, y, z);
        } else {
            u.moveTo(x, y, z);
        }
        u.fallDistance = 0;
    }

    /** Horizontal look direction (never zero). */
    public static Vec3 flatLook(Player u) {
        Vec3 l = u.getLookAngle();
        Vec3 f = new Vec3(l.x, 0, l.z);
        return f.lengthSqr() < 0.0001 ? new Vec3(0, 0, 1) : f.normalize();
    }

    /** Two unit vectors perpendicular to dir. */
    public static Vec3[] basis(Vec3 dir) {
        Vec3 up = Math.abs(dir.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 a = dir.cross(up).normalize();
        Vec3 b = dir.cross(a).normalize();
        return new Vec3[]{a, b};
    }

    /** Where the player's look ray ends (first block, or max range). */
    public static Vec3 rayEnd(ServerLevel sw, Player u, double range) {
        Vec3 eye = u.getEyePosition();
        Vec3 end = eye.add(u.getLookAngle().scale(range));
        BlockHitResult bh = sw.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, u));
        return bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
    }

    /** What the player is looking at: a living entity if there is one on the ray, else the block / far point. */
    public static Target pick(ServerLevel sw, Player u, double range) {
        Vec3 eye = u.getEyePosition();
        Vec3 end = rayEnd(sw, u, range);
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        Vec3 bestP = null;
        List<LivingEntity> near = sw.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(1.5),
                x -> x != u && x.isAlive() && !x.isSpectator());
        for (LivingEntity e : near) {
            Optional<Vec3> hit = e.getBoundingBox().inflate(0.3).clip(eye, end);
            if (hit.isPresent()) {
                double d = eye.distanceToSqr(hit.get());
                if (d < bestD) {
                    bestD = d;
                    best = e;
                    bestP = hit.get();
                }
            }
        }
        if (best != null) return new Target(bestP, best);
        return new Target(end, null);
    }

    /** Hostile mobs within `radius` of the segment eye -> eye+dir*len. */
    public static List<Mob> nearRay(ServerLevel sw, Vec3 eye, Vec3 dir, double len, double radius) {
        Vec3 end = eye.add(dir.scale(len));
        List<Mob> out = new ArrayList<>();
        for (Mob m : sw.getEntitiesOfClass(Mob.class, new AABB(eye, end).inflate(radius + 1), Util::isFoe)) {
            Vec3 p = m.position().add(0, m.getBbHeight() / 2, 0);
            double t = Mth.clamp(p.subtract(eye).dot(dir), 0, len);
            if (eye.add(dir.scale(t)).distanceTo(p) <= radius + m.getBbWidth() / 2) out.add(m);
        }
        return out;
    }

    /** Short-range teleport along the look direction. Returns false if there is no room. */
    public static boolean blink(ServerLevel sw, Player u, double max) {
        Vec3 eye = u.getEyePosition();
        Vec3 dir = u.getLookAngle();
        Vec3 end = rayEnd(sw, u, max);
        double reach = eye.distanceTo(end) - 0.6;
        Vec3 from = u.position();
        for (double d = Math.min(max, reach); d >= 1.5; d -= 0.5) {
            Vec3 cand = from.add(dir.scale(d));
            AABB box = u.getBoundingBox().move(cand.subtract(from));
            if (sw.noCollision(u, box)) {
                Fx.line(sw, Pal.YELLOW, from.add(0, 1, 0), cand.add(0, 1, 0), 0.7);
                Fx.fog(sw, from.add(0, 1, 0), 1.2, 24);
                tp(u, cand.x, cand.y, cand.z);
                Fx.fog(sw, cand.add(0, 1, 0), 1.2, 24);
                return true;
            }
        }
        return false;
    }

    /** Summon a friendly mob that disappears after `lifetime` ticks. */
    public static Mob ally(ServerLevel sw, Player u, EntityType<?> type, Vec3 pos, int lifetime, String name) {
        Entity e = null;
        try {
            e = type.create(sw);
        } catch (Exception ignored) {
        }
        if (!(e instanceof Mob mob)) return null;
        mob.moveTo(pos.x, pos.y, pos.z, u.getYRot(), 0f);
        try {
            DifficultyInstance diff = sw.getCurrentDifficultyAt(mob.blockPosition());
            mob.finalizeSpawn(sw, diff, MobSpawnType.MOB_SUMMONED, null, null);
        } catch (Exception ignored) {
        }
        if (mob instanceof IronGolem g) g.setPlayerCreated(true);
        if (mob instanceof TamableAnimal t) t.tame(u);
        mob.setPersistenceRequired();
        mob.addTag(ALLY);
        mob.setTarget(null);
        mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, lifetime, 1, false, false));
        mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, lifetime, 1, false, false));
        mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, lifetime, 0, false, false));
        if (name != null) {
            mob.setCustomName(Component.literal(name));
            mob.setCustomNameVisible(true);
        }
        LIVE.put(mob.getUUID(), sw.getGameTime() + lifetime + 40);
        sw.addFreshEntity(mob);
        Fx.burst(sw, ParticleTypes.END_ROD, pos.x, pos.y + 1, pos.z, 30, 0.5, 0.8, 0.5, 0.1);
        Fx.burst(sw, Pal.DREAM, pos.x, pos.y + 1, pos.z, 20, 0.5, 0.8, 0.5, 0);
        Scheduler.later(lifetime, () -> {
            if (!mob.isRemoved()) {
                Fx.burst(sw, ParticleTypes.POOF, mob.getX(), mob.getY() + 1, mob.getZ(), 20, 0.4, 0.6, 0.4, 0.05);
                Fx.burst(sw, Pal.WHITE, mob.getX(), mob.getY() + 1, mob.getZ(), 15, 0.4, 0.6, 0.4, 0);
                mob.discard();
            }
        });
        return mob;
    }
}

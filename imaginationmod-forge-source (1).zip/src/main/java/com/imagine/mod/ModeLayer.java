package com.imagine.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Drawn on every player (so other players see it too):
 *  - a coloured glow shell around the body in any mode,
 *  - LIMINAL: a fever-dream tesseract PNG that changes colour and warps across the face,
 *  - NIGHTMARE: a 3D shape on the head that morphs sphere -> pyramid -> cube and hides the face.
 */
public class ModeLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation WHITE = new ResourceLocation(ImaginationMod.MOD_ID, "textures/misc/white.png");
    private static final ResourceLocation TESSERACT = new ResourceLocation(ImaginationMod.MOD_ID, "textures/misc/tesseract.png");
    private static final ResourceLocation GLITCH = new ResourceLocation(ImaginationMod.MOD_ID, "textures/misc/nightmare.png");

    private static final int LAT = 10;
    private static final int LON = 16;
    private static final float[] PX = new float[(LAT + 1) * (LON + 1)];
    private static final float[] PY = new float[(LAT + 1) * (LON + 1)];
    private static final float[] PZ = new float[(LAT + 1) * (LON + 1)];

    public ModeLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible() || player.isSpectator()) return;
        Integer mode = ClientModes.MAP.get(player.getUUID());
        if (mode == null || mode < 0) return;

        aura(pose, buffers, mode, ageInTicks);
        if (mode == Modes.LIMINAL) {
            tesseract(pose, buffers, ageInTicks);
        } else if (mode == Modes.NIGHTMARE) {
            nightmare(pose, buffers, ageInTicks);
        }
    }

    // ───────────────────────── glow shell ─────────────────────────

    private void aura(PoseStack pose, MultiBufferSource buffers, int mode, float t) {
        float[] c = Modes.rgb(mode, t);
        float pulse = 0.5f + 0.5f * Mth.sin(t * 0.12f);
        float alpha = 0.22f + 0.2f * pulse;
        float s = 1.05f + 0.03f * pulse;
        pose.pushPose();
        pose.translate(0.0F, 0.75F, 0.0F);
        pose.scale(s, s, s);
        pose.translate(0.0F, -0.75F, 0.0F);
        VertexConsumer vc = buffers.getBuffer(RenderType.eyes(WHITE));
        this.getParentModel().renderToBuffer(pose, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                c[0], c[1], c[2], alpha);
        pose.popPose();
    }

    // ───────────────────────── LIMINAL: fever-dream tesseract ─────────────────────────

    private void tesseract(PoseStack pose, MultiBufferSource buffers, float t) {
        pose.pushPose();
        this.getParentModel().head.translateAndRotate(pose);
        pose.translate(0.0F, -0.25F, 0.0F); // centre of the head
        VertexConsumer vc = buffers.getBuffer(RenderType.eyes(TESSERACT));
        for (int i = 0; i < 3; i++) {
            float[] col = Modes.hsv(t * 0.012f + i * 0.31f, 0.75f, 1f);
            int cr = (int) (col[0] * 255), cg = (int) (col[1] * 255), cb = (int) (col[2] * 255);
            float size = 0.27f + i * 0.06f + 0.02f * Mth.sin(t * 0.2f + i);
            pose.pushPose();
            // the face of the head is on the -Z side in model space
            pose.translate(0.03f * Mth.sin(t * 0.13f + i * 2f), 0.03f * Mth.cos(t * 0.11f + i), -0.262f - i * 0.01f);
            pose.mulPose(Axis.ZP.rotationDegrees((i % 2 == 0 ? 1f : -1f) * t * (2.5f + i * 1.5f)));
            Matrix4f m = pose.last().pose();
            Matrix3f n = pose.last().normal();
            float[] ox = new float[4];
            float[] oy = new float[4];
            for (int k = 0; k < 4; k++) { // each corner wobbles on its own: the "abstract" warping
                ox[k] = Mth.sin(t * 0.09f + k * 1.7f + i) * 0.03f;
                oy[k] = Mth.cos(t * 0.08f + k * 2.3f + i) * 0.03f;
            }
            float[] qx = {-size + ox[0], size + ox[1], size + ox[2], -size + ox[3]};
            float[] qy = {-size + oy[0], -size + oy[1], size + oy[2], size + oy[3]};
            float[] qu = {0f, 1f, 1f, 0f};
            float[] qv = {1f, 1f, 0f, 0f};
            int alpha = 150 + 40 * i;
            for (int k = 0; k < 4; k++) { // front winding
                vert(vc, m, n, qx[k], qy[k], 0f, qu[k], qv[k], cr, cg, cb, alpha, 0f, 0f, -1f);
            }
            for (int k = 3; k >= 0; k--) { // back winding, so it shows whichever way culling goes
                vert(vc, m, n, qx[k], qy[k], 0f, qu[k], qv[k], cr, cg, cb, alpha, 0f, 0f, 1f);
            }
            pose.popPose();
        }
        pose.popPose();
    }

    // ───────────────────────── NIGHTMARE: morphing censor shape ─────────────────────────

    /** Distance from the head centre to the surface of shape `shape` in unit direction (dx,dy,dz). */
    private static float radial(int shape, float dx, float dy, float dz) {
        switch (shape) {
            case 0: // sphere
                return 0.40f;
            case 1: { // pyramid (tetrahedron), tips trimmed so it stays near the head
                float m = Math.max(Math.max(dx + dy + dz, dx - dy - dz), Math.max(-dx + dy - dz, -dx - dy + dz)) / 1.7320508f;
                return Math.min(0.34f / Math.max(m, 0.05f), 0.80f);
            }
            default: { // cube
                float m = Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz)));
                return 0.33f / Math.max(m, 0.05f);
            }
        }
    }

    private void nightmare(PoseStack pose, MultiBufferSource buffers, float t) {
        float cycle = t / 60f;
        int a = ((int) Math.floor(cycle)) % 3;
        int b = (a + 1) % 3;
        float f = cycle - (float) Math.floor(cycle);
        float k = Mth.clamp((f - 0.5f) / 0.5f, 0f, 1f); // hold the shape, then melt into the next
        k = k * k * (3f - 2f * k);

        pose.pushPose();
        this.getParentModel().head.translateAndRotate(pose);
        pose.translate(0.0F, -0.25F, 0.0F);
        pose.mulPose(Axis.YP.rotationDegrees(t * 3.5f));
        pose.mulPose(Axis.XP.rotationDegrees(t * 1.7f));
        pose.mulPose(Axis.ZP.rotationDegrees(t * 0.9f));

        for (int i = 0; i <= LAT; i++) {
            float th = (float) Math.PI * i / LAT;
            float st = Mth.sin(th);
            float ct = Mth.cos(th);
            for (int j = 0; j <= LON; j++) {
                float ph = (float) (Math.PI * 2) * j / LON;
                float dx = st * Mth.cos(ph);
                float dy = ct;
                float dz = st * Mth.sin(ph);
                float r = Mth.lerp(k, radial(a, dx, dy, dz), radial(b, dx, dy, dz));
                int idx = i * (LON + 1) + j;
                PX[idx] = dx * r;
                PY[idx] = dy * r;
                PZ[idx] = dz * r;
            }
        }

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GLITCH));
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        float flick = 0.8f + 0.2f * Mth.sin(t * 0.7f);
        int cr = (int) (255 * 0.85f * flick);
        int cg = (int) (255 * 0.6f * flick);
        int cb = (int) (255 * 1.0f * flick);
        for (int i = 0; i < LAT; i++) {
            for (int j = 0; j < LON; j++) {
                int i00 = i * (LON + 1) + j;
                int i01 = i00 + 1;
                int i10 = (i + 1) * (LON + 1) + j;
                int i11 = i10 + 1;
                float u0 = j / (float) LON;
                float u1 = (j + 1) / (float) LON;
                float v0 = i / (float) LAT;
                float v1 = (i + 1) / (float) LAT;
                vert(vc, m, n, PX[i00], PY[i00], PZ[i00], u0, v0, cr, cg, cb, 255, PX[i00], PY[i00], PZ[i00]);
                vert(vc, m, n, PX[i10], PY[i10], PZ[i10], u0, v1, cr, cg, cb, 255, PX[i10], PY[i10], PZ[i10]);
                vert(vc, m, n, PX[i11], PY[i11], PZ[i11], u1, v1, cr, cg, cb, 255, PX[i11], PY[i11], PZ[i11]);
                vert(vc, m, n, PX[i01], PY[i01], PZ[i01], u1, v0, cr, cg, cb, 255, PX[i01], PY[i01], PZ[i01]);
            }
        }
        pose.popPose();
    }

    private static void vert(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z, float u, float v,
                             int r, int g, int b, int a, float nx, float ny, float nz) {
        vc.vertex(m, x, y, z).color(r, g, b, a).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT)
                .normal(n, nx, ny, nz).endVertex();
    }
}

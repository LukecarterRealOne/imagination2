package com.imagine.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.UUID;

/** The G / B menu. Each tab is a MODE (glow + visuals); click an ability to cast it. */
public class AbilityScreen extends Screen {
    private static int page = 0;
    /** The ability the R key re-casts (-1 = random). */
    public static int lastPick = -1;

    public AbilityScreen() {
        super(Component.literal("Imagination"));
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            UUID me = mc.player.getUUID();
            Integer mode = ClientModes.MAP.get(me);
            if (mode != null && mode >= 0) page = mode;
        }
    }

    private static void send(int mode, int ability, int action) {
        ImaginationMod.CHANNEL.sendToServer(new SelectPacket(mode, ability, action));
    }

    @Override
    protected void init() {
        // mode tabs
        int tabW = 62, tabGap = 3, tabs = Abilities.CAT_NAMES.length;
        int tabX = this.width / 2 - (tabs * tabW + (tabs - 1) * tabGap) / 2;
        for (int c = 0; c < tabs; c++) {
            final int ci = c;
            Button tab = Button.builder(Component.literal(Abilities.CAT_NAMES[c]), b -> {
                page = ci;
                send(ci, -1, 0); // entering a tab switches you into that mode
                this.rebuildWidgets();
            }).bounds(tabX + c * (tabW + tabGap), 20, tabW, 16).build();
            tab.active = (c != page);
            this.addRenderableWidget(tab);
        }

        // abilities of this mode, 3 columns
        int cols = 3, bw = 130, bh = 18, gap = 3;
        int startX = this.width / 2 - (cols * bw + (cols - 1) * gap) / 2;
        int startY = 54;
        int from = Abilities.CAT_START[page];
        int to = Abilities.catEnd(page);
        for (int i = from; i < to; i++) {
            final int idx = i;
            int n = i - from;
            int x = startX + (n % cols) * (bw + gap);
            int y = startY + (n / cols) * (bh + gap);
            Abilities.Ability ab = Abilities.ALL[i];
            Button btn = Button.builder(Component.literal(ab.name()), b -> {
                lastPick = idx;
                send(-1, idx, 1);
                this.onClose();
            }).bounds(x, y, bw, bh).tooltip(Tooltip.create(Component.literal(ab.desc()))).build();
            this.addRenderableWidget(btn);
        }

        // footer
        int fy = startY + 6 * (bh + gap) + 4;
        this.addRenderableWidget(Button.builder(Component.literal("Random cast"), b -> {
            lastPick = -1;
            send(-1, -1, 1);
            this.onClose();
        }).bounds(this.width / 2 - 135, fy, 90, 18).build());
        this.addRenderableWidget(Button.builder(Component.literal("Aura off"), b -> {
            send(-1, -1, 0);
            this.onClose();
        }).bounds(this.width / 2 - 41, fy, 80, 18).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> this.onClose())
                .bounds(this.width / 2 + 43, fy, 92, 18).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, "\u00a7d\u00a7oImagination", this.width / 2, 6, 0xFFFFFF);
        g.drawCenteredString(this.font,
                "\u00a77Tabs switch your mode (glow). Click an ability to cast it. R repeats your last pick.",
                this.width / 2, 40, 0xAAAAAA);
        super.render(g, mx, my, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

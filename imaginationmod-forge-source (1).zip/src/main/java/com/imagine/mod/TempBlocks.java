package com.imagine.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Blocks that exist only for a while. Only ever replaces AIR, and always puts AIR back,
 * so imagination never destroys your world. Anything still standing is removed on server stop.
 */
public final class TempBlocks {
    private TempBlocks() {}

    private record Entry(ServerLevel level, BlockPos pos, BlockState state) {}

    private static final List<Entry> ACTIVE = new ArrayList<>();

    public static int placeAll(ServerLevel sw, Map<BlockPos, BlockState> blocks, int ticks) {
        List<Entry> placed = new ArrayList<>();
        for (Map.Entry<BlockPos, BlockState> me : blocks.entrySet()) {
            BlockPos pos = me.getKey().immutable();
            if (!sw.isInWorldBounds(pos) || !sw.getBlockState(pos).isAir()) continue;
            if (sw.setBlock(pos, me.getValue(), 3)) placed.add(new Entry(sw, pos, me.getValue()));
        }
        ACTIVE.addAll(placed);
        if (!placed.isEmpty()) Scheduler.later(ticks, () -> restore(placed));
        return placed.size();
    }

    private static void restore(List<Entry> list) {
        for (Entry en : list) {
            if (ACTIVE.remove(en) && en.level().getBlockState(en.pos()) == en.state()) {
                en.level().setBlock(en.pos(), Blocks.AIR.defaultBlockState(), 3);
            }
        }
    }

    public static void restoreAll() {
        restore(new ArrayList<>(ACTIVE));
    }
}

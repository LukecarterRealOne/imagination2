package com.imagine.mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Client-side copy of every player's current mode (so you can see other people's glow and faces). */
public final class ClientModes {
    private ClientModes() {}

    public static final Map<UUID, Integer> MAP = new HashMap<>();

    public static void set(UUID id, int mode) {
        MAP.put(id, mode);
    }
}

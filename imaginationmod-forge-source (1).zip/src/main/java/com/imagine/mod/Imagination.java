package com.imagine.mod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Server-side brain: who is in which mode, cooldowns, casting, and syncing modes to everyone. */
@Mod.EventBusSubscriber(modid = ImaginationMod.MOD_ID)
public final class Imagination {
    private Imagination() {}

    /** Players who currently can't be hurt (Intangible). */
    public static final Set<UUID> SHIELDED = new HashSet<>();

    private static final Map<UUID, Integer> MODES = new HashMap<>();
    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();
    private static final String KEY = "imagination_mode";

    public static int categoryOf(int ability) {
        int cat = 0;
        for (int c = 0; c < Abilities.CAT_START.length; c++) {
            if (ability >= Abilities.CAT_START[c]) cat = c;
        }
        return cat;
    }

    public static int modeOf(UUID id) {
        return MODES.getOrDefault(id, -1);
    }

    /** Switch a player's mode (-1 = off) and tell every client so the glow / face effects show up for everyone. */
    public static void setMode(ServerPlayer p, int mode, boolean announce) {
        int m = (mode < 0 || mode >= Abilities.CAT_NAMES.length) ? -1 : mode;
        if (modeOf(p.getUUID()) == m) return;
        MODES.put(p.getUUID(), m);
        p.getPersistentData().putInt(KEY, m);
        ImaginationMod.CHANNEL.send(PacketDistributor.ALL.noArg(), new ModePacket(p.getUUID(), m));
        if (announce) {
            Util.msg(p, m < 0 ? "\u00a77Aura off" : "\u00a7dMode: \u00a7f" + Abilities.CAT_NAMES[m]);
        }
    }

    public static void onSelect(ServerPlayer p, int mode, int ability, int action) {
        if (action == 0) {
            setMode(p, mode, true);
        } else if (action == 1) {
            cast(p, ability);
        }
    }

    /** Cast ability `index` (out of range = random). Casting also switches you into that ability's mode. */
    public static void cast(ServerPlayer p, int index) {
        ServerLevel sw = p.serverLevel();
        int a = index;
        if (a < 0 || a >= Abilities.COUNT) a = sw.random.nextInt(Abilities.COUNT);
        Abilities.Ability ab = Abilities.ALL[a];
        long now = sw.getGameTime();
        long[] ready = COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new long[Abilities.COUNT]);
        if (now < ready[a]) {
            long secs = (ready[a] - now + 19) / 20;
            Util.msg(p, "\u00a7c" + ab.name() + " is recovering (" + secs + "s)");
            return;
        }
        ready[a] = now + ab.cooldown();
        setMode(p, categoryOf(a), false);
        Util.msg(p, "\u00a7d\u00a7o" + ab.name());
        try {
            ab.run().cast(sw, p);
        } catch (Exception ex) {
            ex.printStackTrace();
            Util.msg(p, "\u00a7cThe dream slipped away...");
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;
        if (!MODES.containsKey(sp.getUUID()) && sp.getPersistentData().contains(KEY)) {
            MODES.put(sp.getUUID(), sp.getPersistentData().getInt(KEY));
        }
        // show the newcomer everyone who is already glowing...
        for (Map.Entry<UUID, Integer> en : MODES.entrySet()) {
            ImaginationMod.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new ModePacket(en.getKey(), en.getValue()));
        }
        // ...and show everyone the newcomer
        Integer mine = MODES.get(sp.getUUID());
        if (mine != null) {
            ImaginationMod.CHANNEL.send(PacketDistributor.ALL.noArg(), new ModePacket(sp.getUUID(), mine));
        }
    }

    /** Faint ambient particles around anyone in a mode (the 3D glow / face effects are drawn client-side). */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer sp)) return;
        if (sp.tickCount % 8 != 0 || sp.isSpectator()) return;
        int mode = modeOf(sp.getUUID());
        if (mode < 0) return;
        ServerLevel sw = sp.serverLevel();
        double x = sp.getX(), y = sp.getY() + 1.0, z = sp.getZ();
        switch (mode) {
            case Modes.DREAM -> {
                Fx.burst(sw, ParticleTypes.END_ROD, x, y, z, 1, 0.6, 0.8, 0.6, 0.01);
                Fx.burst(sw, Pal.DREAM, x, y, z, 2, 0.6, 0.8, 0.6, 0);
            }
            case Modes.LIMINAL -> {
                Fx.burst(sw, ParticleTypes.WHITE_ASH, x, y, z, 3, 0.9, 0.8, 0.9, 0);
                Fx.burst(sw, Pal.HAZE, x, y, z, 1, 0.6, 0.8, 0.6, 0);
            }
            case Modes.CREATION -> {
                Fx.burst(sw, Pal.MINT, x, y, z, 2, 0.6, 0.8, 0.6, 0);
                Fx.burst(sw, ParticleTypes.HAPPY_VILLAGER, x, y, z, 1, 0.6, 0.8, 0.6, 0);
            }
            case Modes.REALITY -> {
                Fx.burst(sw, ParticleTypes.REVERSE_PORTAL, x, y, z, 2, 0.5, 0.8, 0.5, 0.05);
                Fx.burst(sw, Pal.LAVENDER, x, y, z, 1, 0.6, 0.8, 0.6, 0);
            }
            case Modes.NIGHTMARE -> {
                Fx.burst(sw, ParticleTypes.SCULK_SOUL, x, y - 0.5, z, 1, 0.5, 0.5, 0.5, 0.02);
                Fx.burst(sw, ParticleTypes.ASH, x, y, z, 3, 0.8, 0.8, 0.8, 0);
                Fx.burst(sw, Pal.DREAD, x, y, z, 1, 0.5, 0.8, 0.5, 0);
            }
            default -> {
                Fx.burst(sw, Pal.rainbow(sw.random.nextFloat()), x, y, z, 2, 0.6, 0.8, 0.6, 0);
                Fx.burst(sw, ParticleTypes.END_ROD, x, y, z, 1, 0.6, 0.8, 0.6, 0.01);
            }
        }
    }
}

package com.imagine.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Nightmare (47-55) and Wonder (56-72). */
public final class PowersC {
    private PowersC() {}

    // ───────────────────────── NIGHTMARE ─────────────────────────

    static void nightmareBeam(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, 3f, 0.5f);
        Fx.screen(sw, u.position(), 40, 0.4f, 2f, 20, 0x1A0A28);
        Util.loop(40, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 eye = u.getEyePosition();
            Vec3 dir = u.getLookAngle();
            Vec3 end = Util.rayEnd(sw, u, 40);
            double len = eye.distanceTo(end);
            Vec3[] ax = Util.basis(dir);
            int n = 0;
            for (double d = 1.5; d <= len; d += 0.8) {
                Vec3 p = eye.add(dir.scale(d)).add(0, -0.3, 0);
                Fx.burst(sw, Pal.DREAD, p.x, p.y, p.z, 1, 0.15, 0.15, 0.15, 0);
                double ang = d * 1.1 + t * 0.8;
                Vec3 o = ax[0].scale(Math.cos(ang) * 0.9).add(ax[1].scale(Math.sin(ang) * 0.9));
                Fx.burst(sw, Pal.VOID, p.x + o.x, p.y + o.y, p.z + o.z, 1, 0, 0, 0, 0);
                if (n++ % 4 == 0) Fx.burst(sw, ParticleTypes.SCULK_SOUL, p.x, p.y, p.z, 1, 0.3, 0.3, 0.3, 0.02);
            }
            Fx.burst(sw, ParticleTypes.SQUID_INK, end.x, end.y, end.z, 8, 0.4, 0.4, 0.4, 0.05);
            if (t % 5 == 0) {
                for (Mob m : Util.nearRay(sw, eye, dir, len, 2.2)) {
                    Util.hurt(sw, u, m, 10f);
                    m.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 1));
                }
            }
        });
    }

    static void sleepParalysis(ServerLevel sw, Player u) {
        Util.Target tg = Util.pick(sw, u, 40);
        final List<Mob> victims = new ArrayList<>();
        LivingEntity hit = tg.entity();
        if (hit instanceof Mob hm && Util.isFoe(hm)) {
            victims.add(hm);
        } else {
            victims.addAll(Util.foes(sw, tg.pos(), 5));
        }
        final List<Mob> frozen = new ArrayList<>();
        for (Mob m : victims) {
            if (!m.isNoAi()) {
                m.setNoAi(true);
                frozen.add(m);
            }
            m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 140, 4, false, false));
            m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 140, 0, false, false));
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.ELDER_GUARDIAN_CURSE, 1.5f, 0.6f);
        Util.loop(120, 1, t -> {
            for (Mob m : victims) {
                if (!m.isAlive()) continue;
                Fx.burst(sw, ParticleTypes.SCULK_SOUL, m.getX(), m.getY() + 0.2 + (t % 20) * 0.1, m.getZ(), 2, 0.4, 0.2, 0.4, 0.02);
                Fx.burst(sw, Pal.DREAD, m.getX(), m.getY() + 1, m.getZ(), 2, 0.4, 0.6, 0.4, 0);
            }
        });
        Scheduler.later(122, () -> {
            for (Mob m : frozen) {
                if (m.isAlive()) m.setNoAi(false);
            }
        });
    }

    static void shadowHands(ServerLevel sw, Player u) {
        List<Mob> all = new ArrayList<>(Util.foes(sw, u.position(), 20));
        all.sort(Comparator.comparingDouble((Mob m) -> m.distanceToSqr(u)));
        final List<Mob> targets = new ArrayList<>(all.subList(0, Math.min(6, all.size())));
        Fx.sound(sw, u.blockPosition(), SoundEvents.ELDER_GUARDIAN_CURSE, 1.5f, 0.5f);
        for (int g = 0; g < 4; g++) {
            Scheduler.later(g * 14 + 1, () -> {
                for (Mob m : targets) {
                    if (!m.isAlive()) continue;
                    double bx = m.getX(), by = m.getY(), bz = m.getZ();
                    for (int f = 0; f < 5; f++) {
                        double a = f * Math.PI * 2 / 5;
                        for (double y = 0; y <= 2.4; y += 0.3) {
                            double rad = 0.9 - y * 0.15;
                            Fx.burst(sw, Pal.DREAD, bx + Math.cos(a) * rad, by + y, bz + Math.sin(a) * rad, 1, 0, 0, 0, 0);
                        }
                    }
                    Fx.burst(sw, ParticleTypes.SCULK_SOUL, bx, by + 0.5, bz, 8, 0.4, 0.6, 0.4, 0.04);
                    Fx.burst(sw, ParticleTypes.ASH, bx, by + 1, bz, 10, 0.5, 0.8, 0.5, 0);
                    Util.hurt(sw, u, m, 6f);
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 4, false, false));
                }
                Fx.sound(sw, u.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, 2f, 0.6f);
            });
        }
    }

    static void whispers(ServerLevel sw, Player u) {
        Fx.screen(sw, u.position(), 30, 0.35f, 0f, 1, 0x2A1838);
        Util.loop(60, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 here = u.position();
            if (t % 15 == 0) {
                Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_STARE, 1.5f, 0.5f + (t % 30) * 0.01f);
                Fx.sound(sw, u.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, 2f, 0.7f);
            }
            for (Mob m : Util.foes(sw, here, 24)) {
                if (t % 10 == 0) {
                    m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false));
                }
                Fx.burst(sw, ParticleTypes.SCULK_SOUL, m.getX(), m.getY() + 0.3 + (t % 20) * 0.1, m.getZ(), 1, 0.3, 0.2, 0.3, 0.01);
            }
            Fx.burst(sw, ParticleTypes.SCULK_SOUL, here.x, here.y + 1, here.z, 2, 6, 2, 6, 0.01);
        });
    }

    static void theStalker(ServerLevel sw, Player u) {
        Vec3 spot = u.position().subtract(Util.flatLook(u).scale(5));
        final Mob stalker = Util.ally(sw, u, EntityType.IRON_GOLEM, spot, 800, "\u00a78\u00a7oThe Stalker");
        if (stalker == null) return;
        stalker.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1, false, false));
        stalker.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 3, false, false));
        Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_STARE, 2f, 0.4f);
        Fx.screen(sw, u.position(), 30, 0.4f, 0f, 1, 0x100818);
        Util.loop(400, 2, t -> {
            if (stalker.isRemoved() || !stalker.isAlive()) return;
            Fx.burst(sw, Pal.DREAD, stalker.getX(), stalker.getY() + 1.5, stalker.getZ(), 4, 0.5, 1.0, 0.5, 0);
            Fx.burst(sw, ParticleTypes.SCULK_SOUL, stalker.getX(), stalker.getY() + 0.5, stalker.getZ(), 1, 0.4, 0.3, 0.4, 0.01);
            Fx.burst(sw, ParticleTypes.ASH, stalker.getX(), stalker.getY() + 2, stalker.getZ(), 3, 0.5, 0.8, 0.5, 0);
        });
    }

    static void fearAura(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.ELDER_GUARDIAN_CURSE, 2f, 0.7f);
        Fx.screen(sw, u.position(), 30, 0.4f, 3f, 8, 0x1A0A28);
        Util.loop(25, 4, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 here = u.position();
            for (Mob m : Util.foes(sw, here, 16)) {
                Vec3 away = m.position().subtract(here);
                away = new Vec3(away.x, 0, away.z);
                away = away.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : away.normalize();
                m.setTarget(null);
                m.getNavigation().moveTo(m.getX() + away.x * 10, m.getY(), m.getZ() + away.z * 10, 1.4);
            }
            Fx.ring(sw, Pal.VOID, here.x, here.y + 0.3, here.z, 2 + (t % 8) * 1.6, 40);
            Fx.burst(sw, ParticleTypes.ASH, here.x, here.y + 1, here.z, 12, 8, 2, 8, 0);
        });
    }

    static void uncannySmile(ServerLevel sw, Player u) {
        final List<Mob> victims = Util.foes(sw, u.position(), 14);
        for (Mob m : victims) {
            m.addEffect(new MobEffectInstance(MobEffects.WITHER, 120, 1));
            m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 120, 0, false, false));
            m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1, false, false));
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_STARE, 2f, 0.3f);
        Util.loop(40, 2, t -> {
            for (Mob m : victims) {
                if (!m.isAlive()) continue;
                Vec3 toU = u.position().subtract(m.position());
                toU = new Vec3(toU.x, 0, toU.z);
                toU = toU.lengthSqr() < 0.01 ? new Vec3(0, 0, 1) : toU.normalize();
                Vec3 side = new Vec3(-toU.z, 0, toU.x);
                double cy = m.getY() + m.getBbHeight() + 0.9;
                // the smile: lower arc
                for (int i = 0; i <= 14; i++) {
                    double a = Math.PI * (1.15 + 0.7 * i / 14.0);
                    double sx = Math.cos(a) * 0.7;
                    double sy = Math.sin(a) * 0.5;
                    Fx.burst(sw, Pal.WHITE, m.getX() + side.x * sx, cy + sy + 0.4, m.getZ() + side.z * sx, 1, 0, 0, 0, 0);
                }
                // two eyes
                Fx.burst(sw, Pal.WHITE, m.getX() + side.x * 0.28, cy + 0.55, m.getZ() + side.z * 0.28, 1, 0, 0, 0, 0);
                Fx.burst(sw, Pal.WHITE, m.getX() - side.x * 0.28, cy + 0.55, m.getZ() - side.z * 0.28, 1, 0, 0, 0, 0);
            }
        });
    }

    static void echoPulse(ServerLevel sw, Player u) {
        final Vec3 c = u.position();
        for (int p = 0; p < 4; p++) {
            final int pulse = p;
            Scheduler.later(p * 12 + 1, () -> {
                double reach = 4.0 * (pulse + 1);
                Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.WARDEN_SONIC_BOOM, 1.5f, 1.4f - pulse * 0.2f);
                Fx.screen(sw, c, 30, 0.2f, 1.5f, 4, 0xD8D0FF);
                for (Mob m : Util.foes(sw, c, reach)) {
                    if (m.distanceToSqr(c) >= (reach - 4.0) * (reach - 4.0)) {
                        Util.hurt(sw, u, m, 12f);
                        Util.shove(m, c, 0.9, 0.3);
                    }
                }
                Util.loop(10, 1, t -> {
                    double r = (reach - 4.0) + t * 0.4;
                    Fx.ring(sw, ParticleTypes.SONIC_BOOM, c.x, c.y + 1, c.z, Math.max(0.5, r), 6);
                    Fx.ring(sw, Pal.LAVENDER, c.x, c.y + 0.5, c.z, Math.max(0.5, r), 40);
                });
            });
        }
    }

    static void dreadVerdict(ServerLevel sw, Player u) {
        Util.Target tg = Util.pick(sw, u, 50);
        LivingEntity le = tg.entity();
        if (!(le instanceof Mob) || !Util.isFoe((Mob) le)) {
            Util.msg(u, "\u00a7cNo one to judge...");
            return;
        }
        final Mob m = (Mob) le;
        final boolean weak = m.getHealth() <= m.getMaxHealth() * 0.5f;
        Fx.sound(sw, u.blockPosition(), SoundEvents.ELDER_GUARDIAN_CURSE, 2f, 0.5f);
        Fx.screen(sw, u.position(), 30, 0.6f, 3f, 10, 0x000000);
        Util.loop(20, 1, t -> {
            if (!m.isAlive()) return;
            Fx.sphere(sw, Pal.DREAD, m.position().add(0, m.getBbHeight() / 2, 0), 3 - t * 0.12, 30, t * 0.3);
            Fx.burst(sw, ParticleTypes.SCULK_SOUL, m.getX(), m.getY() + 1, m.getZ(), 3, 0.5, 0.8, 0.5, 0.05);
        });
        Scheduler.later(22, () -> {
            if (!m.isAlive()) return;
            Vec3 mid = m.position().add(0, m.getBbHeight() / 2, 0);
            if (weak) {
                m.hurt(sw.damageSources().indirectMagic(u, u), 100000f);
                if (m.isAlive()) m.kill();
                Fx.burst(sw, ParticleTypes.SCULK_SOUL, mid.x, mid.y, mid.z, 60, 0.6, 0.8, 0.6, 0.2);
                Fx.burst(sw, ParticleTypes.SQUID_INK, mid.x, mid.y, mid.z, 30, 0.6, 0.8, 0.6, 0.1);
            } else {
                Util.hurt(sw, u, m, 30f);
                m.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 2));
                Fx.burst(sw, ParticleTypes.SCULK_SOUL, mid.x, mid.y, mid.z, 25, 0.5, 0.7, 0.5, 0.1);
            }
            Fx.sound(sw, BlockPos.containing(mid.x, mid.y, mid.z), SoundEvents.GENERIC_EXPLODE, 1.5f, 0.5f);
        });
    }

    // ───────────────────────── WONDER ─────────────────────────

    static void starfall(ServerLevel sw, Player u) {
        final Vec3 c = Util.pick(sw, u, 60).pos();
        Fx.sound(sw, u.blockPosition(), SoundEvents.FIREWORK_ROCKET_TWINKLE, 3f, 0.8f);
        for (int i = 0; i < 14; i++) {
            final Vec3 hit = c.add((sw.random.nextDouble() - 0.5) * 16, 0, (sw.random.nextDouble() - 0.5) * 16);
            final int start = i * 3 + 1;
            for (int s = 0; s < 8; s++) {
                final int stage = s;
                Scheduler.later(start + s, () -> {
                    double h = 24 - stage * 3.0;
                    Fx.burst(sw, ParticleTypes.END_ROD, hit.x + h * 0.15, hit.y + h, hit.z, 3, 0.05, 0.4, 0.05, 0.02);
                    Fx.burst(sw, Pal.CREAM, hit.x + h * 0.15, hit.y + h, hit.z, 2, 0.05, 0.3, 0.05, 0);
                });
            }
            Scheduler.later(start + 8, () -> {
                Fx.burst(sw, ParticleTypes.FIREWORK, hit.x, hit.y + 0.5, hit.z, 40, 0.3, 0.3, 0.3, 0.25);
                Fx.ring(sw, Pal.PINK, hit.x, hit.y + 0.2, hit.z, 2.5, 24);
                Fx.sound(sw, BlockPos.containing(hit.x, hit.y, hit.z), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 1.6f);
                for (Mob m : Util.foes(sw, hit, 3.5)) Util.hurt(sw, u, m, 12f);
            });
        }
    }

    static void aurora(ServerLevel sw, Player u) {
        for (var p : Util.playersNear(sw, u.position(), 16)) {
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 1));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 300, 1));
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_AMBIENT, 3f, 1.4f);
        Fx.screen(sw, u.position(), 40, 0.3f, 0f, 1, 0xC8FFE8);
        Util.loop(80, 2, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 base = u.position();
            for (int r = 0; r < 3; r++) {
                for (int i = 0; i <= 40; i++) {
                    double x = (i - 20) * 0.7;
                    double y = 14 + r * 2 + Math.sin(i * 0.35 + t * 0.16) * 2.2;
                    double z = r * 3 - 3 + Math.cos(i * 0.2 + t * 0.1) * 1.5;
                    Fx.burst(sw, Pal.AURORA, base.x + x, base.y + y, base.z + z, 1, 0.1, 0.5, 0.1, 0);
                }
            }
        });
    }

    static void dreamLightning(ServerLevel sw, Player u) {
        final Vec3 c = Util.pick(sw, u, 50).pos();
        for (int i = 0; i < 8; i++) {
            final Vec3 at = c.add((sw.random.nextDouble() - 0.5) * 12, 0, (sw.random.nextDouble() - 0.5) * 12);
            Scheduler.later(i * 4 + 1, () -> Fx.ring(sw, Pal.LAVENDER, at.x, at.y + 0.1, at.z, 2, 24));
            Scheduler.later(i * 4 + 11, () -> {
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sw);
                if (bolt != null) {
                    bolt.moveTo(at.x, at.y, at.z);
                    bolt.setVisualOnly(true);
                    sw.addFreshEntity(bolt);
                }
                for (Mob m : Util.foes(sw, at, 3.5)) Util.hurt(sw, u, m, 20f);
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, at.x, at.y + 1, at.z, 30, 0.8, 1.2, 0.8, 0.3);
                Fx.burst(sw, Pal.PINK, at.x, at.y + 1, at.z, 15, 0.8, 1.2, 0.8, 0);
                Fx.screen(sw, at, 40, 0.3f, 2f, 4, 0xF0E0FF);
            });
        }
    }

    static void comet(ServerLevel sw, Player u) {
        final Vec3 c = Util.pick(sw, u, 80).pos();
        final Vec3 start = c.add(30, 70, 30);
        final int ticks = 26;
        Fx.sound(sw, u.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 3f, 0.4f);
        Util.loop(ticks, 1, t -> {
            double f = (t + 1) / (double) ticks;
            Vec3 p = start.lerp(c, f);
            Vec3 tail = start.lerp(c, Math.max(0, f - 0.2));
            Fx.sphere(sw, Pal.CREAM, p, 1.6, 18, t);
            Fx.burst(sw, ParticleTypes.END_ROD, p.x, p.y, p.z, 14, 0.8, 0.8, 0.8, 0.05);
            Fx.burst(sw, Pal.DREAM, p.x, p.y, p.z, 8, 1, 1, 1, 0);
            Fx.line(sw, Pal.HAZE, tail, p, 1.0);
        });
        Scheduler.later(ticks + 1, () -> {
            sw.explode(null, c.x, c.y, c.z, 5f, Level.ExplosionInteraction.NONE);
            for (Mob m : Util.foes(sw, c, 9)) {
                Util.hurt(sw, u, m, 40f);
                Util.shove(m, c, 1.5, 0.6);
            }
            Fx.screen(sw, c, 100, 1f, 6f, 20, 0xFFFFFF);
            Fx.burst(sw, ParticleTypes.FLASH, c.x, c.y + 1, c.z, 1, 0, 0, 0, 0);
            Util.loop(14, 1, t -> {
                Fx.ring(sw, Pal.CREAM, c.x, c.y + 0.3, c.z, 1 + t * 0.9, 48);
                Fx.ring(sw, Pal.PINK, c.x, c.y + 0.6, c.z, 1 + t * 0.7, 36);
            });
        });
    }

    static void bubblePrison(ServerLevel sw, Player u) {
        Util.Target tg = Util.pick(sw, u, 40);
        final List<Mob> victims = new ArrayList<>();
        LivingEntity hit = tg.entity();
        if (hit instanceof Mob hm && Util.isFoe(hm)) {
            victims.add(hm);
        }
        victims.addAll(Util.foes(sw, tg.pos(), 3));
        for (Mob m : victims) {
            m.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 100, 0, false, false));
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 5, false, false));
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 0.6f);
        Util.loop(100, 1, t -> {
            for (Mob m : victims) {
                if (!m.isAlive()) continue;
                Vec3 mid = m.position().add(0, m.getBbHeight() / 2, 0);
                Fx.sphere(sw, ParticleTypes.BUBBLE, mid, 1.5 + m.getBbWidth() * 0.4, 12, t * 0.1);
                Fx.sphere(sw, Pal.BLUE, mid, 1.6 + m.getBbWidth() * 0.4, 8, -t * 0.1);
                if (t % 20 == 0) Util.hurt(sw, u, m, 2f);
            }
        });
        Scheduler.later(102, () -> {
            for (Mob m : victims) {
                if (!m.isAlive()) continue;
                Util.hurt(sw, u, m, 10f);
                Fx.burst(sw, ParticleTypes.BUBBLE_POP, m.getX(), m.getY() + 1, m.getZ(), 40, 1, 1, 1, 0.1);
            }
            Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 1.9f);
        });
    }

    static void petalStorm(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, 2f, 1.3f);
        Util.loop(120, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 mid = u.position().add(0, 1, 0);
            double rad = 3 + Math.sin(t * 0.08) * 1.5;
            for (int i = 0; i < 6; i++) {
                double a = t * 0.3 + i * Math.PI / 3;
                double y = mid.y - 0.8 + ((t * 0.1 + i * 0.5) % 3.0);
                Fx.burst(sw, ParticleTypes.CHERRY_LEAVES, mid.x + Math.cos(a) * rad, y, mid.z + Math.sin(a) * rad, 2, 0.1, 0.1, 0.1, 0);
                Fx.burst(sw, Pal.PINK, mid.x + Math.cos(a) * rad, y, mid.z + Math.sin(a) * rad, 1, 0, 0, 0, 0);
            }
            if (t % 8 == 0) {
                for (Mob m : Util.foes(sw, mid, 6)) {
                    Util.hurt(sw, u, m, 3f);
                    Util.shove(m, u.position(), 0.4, 0.15);
                }
            }
        });
    }

    static void sporeDream(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 1));
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, 2f, 0.8f);
        Util.loop(120, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 mid = u.position().add(0, 1.2, 0);
            Fx.burst(sw, ParticleTypes.SPORE_BLOSSOM_AIR, mid.x, mid.y, mid.z, 10, 6, 2, 6, 0);
            Fx.burst(sw, Pal.MINT, mid.x, mid.y, mid.z, 4, 5, 2, 5, 0);
            if (t % 10 == 0) {
                for (Mob m : Util.foes(sw, mid, 10)) {
                    m.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 1, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0, false, false));
                }
            }
        });
    }

    static void lullaby(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 0.5f);
        Util.loop(50, 4, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 here = u.position();
            for (Mob m : Util.foes(sw, here, 20)) {
                m.setTarget(null);
                m.getNavigation().stop();
                m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 4, false, false));
                Fx.burst(sw, ParticleTypes.NOTE, m.getX(), m.getY() + m.getBbHeight() + 0.5, m.getZ(), 1, 0.3, 0.2, 0.3, 0);
            }
            for (int i = 0; i < 6; i++) {
                double a = t * 0.2 + i * Math.PI / 3;
                Fx.burst(sw, ParticleTypes.NOTE, here.x + Math.cos(a) * 2, here.y + 1.5, here.z + Math.sin(a) * 2, 1, 0, 0, 0, 0);
            }
            Fx.burst(sw, Pal.LAVENDER, here.x, here.y + 1, here.z, 5, 3, 1, 3, 0);
        });
    }

    static void makeAWish(ServerLevel sw, Player u) {
        MobEffect[] pool = {MobEffects.MOVEMENT_SPEED, MobEffects.DAMAGE_BOOST, MobEffects.REGENERATION,
                MobEffects.DAMAGE_RESISTANCE, MobEffects.JUMP, MobEffects.NIGHT_VISION, MobEffects.FIRE_RESISTANCE,
                MobEffects.ABSORPTION, MobEffects.DIG_SPEED, MobEffects.LUCK, MobEffects.HEALTH_BOOST,
                MobEffects.WATER_BREATHING};
        List<MobEffect> list = new ArrayList<>(List.of(pool));
        StringBuilder names = new StringBuilder();
        for (int i = 0; i < 3 && !list.isEmpty(); i++) {
            MobEffect e = list.remove(sw.random.nextInt(list.size()));
            u.addEffect(new MobEffectInstance(e, 1200, 1));
            if (i > 0) names.append(", ");
            names.append(e.getDisplayName().getString());
        }
        Util.msg(u, "\u00a7dYour wish: \u00a7f" + names);
        Fx.sound(sw, u.blockPosition(), SoundEvents.FIREWORK_ROCKET_TWINKLE, 3f, 1.0f);
        Fx.screen(sw, u.position(), 30, 0.6f, 0f, 1, 0xFFF0B0);
        Util.loop(40, 1, t -> {
            Fx.spiral(sw, ParticleTypes.END_ROD, u.position(), 1.2, 6, 3, 30, t * 0.3);
            Fx.spiral(sw, Pal.YELLOW, u.position(), 1.0, 6, 3, 20, -t * 0.3);
        });
        Scheduler.later(41, () -> {
            Fx.burst(sw, ParticleTypes.TOTEM_OF_UNDYING, u.getX(), u.getY() + 6, u.getZ(), 80, 0.6, 0.6, 0.6, 0.4);
            Fx.burst(sw, ParticleTypes.FLASH, u.getX(), u.getY() + 6, u.getZ(), 1, 0, 0, 0, 0);
        });
    }

    static void confettiBlast(ServerLevel sw, Player u) {
        final Vec3 c = u.position().add(0, 1, 0);
        Fx.sound(sw, u.blockPosition(), SoundEvents.FIREWORK_ROCKET_BLAST, 3f, 1.0f);
        Fx.screen(sw, c, 30, 0.4f, 2f, 5, 0xFFFFFF);
        for (int i = 0; i < 160; i++) {
            Fx.burst(sw, Pal.rainbow(sw.random.nextFloat()), c.x, c.y, c.z, 1,
                    (sw.random.nextDouble() - 0.5) * 8, (sw.random.nextDouble() - 0.5) * 6, (sw.random.nextDouble() - 0.5) * 8, 0);
        }
        Fx.burst(sw, ParticleTypes.FIREWORK, c.x, c.y, c.z, 60, 0.2, 0.2, 0.2, 0.4);
        for (Mob m : Util.foes(sw, c, 7)) {
            Util.hurt(sw, u, m, 8f);
            Util.shove(m, c, 1.2, 0.5);
        }
    }

    static void phantomOrchestra(ServerLevel sw, Player u) {
        Util.loop(160, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 here = u.position();
            for (int i = 0; i < 4; i++) {
                double a = t * 0.15 + i * Math.PI / 2;
                Fx.burst(sw, ParticleTypes.NOTE, here.x + Math.cos(a) * 2.5, here.y + 1 + Math.sin(t * 0.1 + i) * 0.5, here.z + Math.sin(a) * 2.5, 1, 0, 0, 0, 0);
            }
            Fx.burst(sw, ParticleTypes.END_ROD, here.x, here.y + 1, here.z, 1, 3, 1, 3, 0.01);
            if (t % 10 == 0) {
                Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 0.5f + sw.random.nextFloat() * 1.5f);
            }
            if (t % 20 == 0) Fx.sound(sw, u.blockPosition(), SoundEvents.BELL_BLOCK, 1.5f, 0.6f + sw.random.nextFloat() * 0.8f);
            if (t % 40 == 0) {
                for (var p : Util.playersNear(sw, here, 14)) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1));
                    p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 60, 1));
                }
                for (Mob m : Util.foes(sw, here, 14)) {
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1, false, false));
                }
            }
        });
    }

    private record Anchor(ResourceKey<Level> dim, Vec3 pos) {}

    private static final Map<UUID, Anchor> ANCHORS = new HashMap<>();

    static void memoryAnchor(ServerLevel sw, Player u) {
        Anchor old = ANCHORS.get(u.getUUID());
        if (old == null || old.dim() != sw.dimension()) {
            ANCHORS.put(u.getUUID(), new Anchor(sw.dimension(), u.position()));
            Util.msg(u, "\u00a7dMemory anchored. Cast again to return here.");
            Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, 2f, 1.2f);
            final Vec3 here = u.position();
            Util.loop(30, 1, t -> {
                Fx.column(sw, Pal.LAVENDER, here, 3, 0.4, 0.3);
                Fx.ring(sw, ParticleTypes.END_ROD, here.x, here.y + 0.2 + t * 0.1, here.z, 1.2, 14);
            });
            return;
        }
        ANCHORS.remove(u.getUUID());
        Vec3 dest = old.pos();
        Fx.fog(sw, u.position().add(0, 1, 0), 2, 30);
        Fx.burst(sw, ParticleTypes.REVERSE_PORTAL, u.getX(), u.getY() + 1, u.getZ(), 40, 0.5, 1, 0.5, 0.3);
        Util.tp(u, dest.x, dest.y, dest.z);
        Fx.fog(sw, dest.add(0, 1, 0), 2, 30);
        Fx.burst(sw, ParticleTypes.END_ROD, dest.x, dest.y + 1, dest.z, 40, 0.5, 1, 0.5, 0.1);
        Fx.screen(sw, dest, 30, 0.5f, 1f, 4, 0xE8E0FF);
        Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2f, 0.9f);
    }

    static void epiphany(ServerLevel sw, Player u) {
        u.giveExperiencePoints(300);
        u.setHealth(u.getMaxHealth());
        u.addEffect(new MobEffectInstance(MobEffects.LUCK, 1200, 1));
        Fx.sound(sw, u.blockPosition(), SoundEvents.PLAYER_LEVELUP, 2f, 1.0f);
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_POWER_SELECT, 2f, 1.5f);
        Fx.screen(sw, u.position(), 40, 0.9f, 0f, 1, 0xFFF7B0);
        Fx.burst(sw, ParticleTypes.FLASH, u.getX(), u.getY() + 2.5, u.getZ(), 1, 0, 0, 0, 0);
        Util.loop(30, 1, t -> {
            Fx.column(sw, Pal.YELLOW, u.position(), 12, 0.5, 0.3);
            Fx.column(sw, ParticleTypes.END_ROD, u.position(), 12, 1.0, 0.4);
            Fx.ring(sw, Pal.CREAM, u.getX(), u.getY() + 2.5, u.getZ(), 0.5 + t * 0.15, 20);
        });
    }

    static void supernova(ServerLevel sw, Player u) {
        final Vec3 c = u.position().add(0, 2, 0);
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_ACTIVATE, 3f, 0.4f);
        Util.loop(40, 1, t -> {
            double r = 12 * (1 - t / 40.0) + 1;
            Fx.sphere(sw, Pal.YELLOW, c, r, 50, t * 0.3);
            Fx.sphere(sw, ParticleTypes.END_ROD, c, r * 0.8, 20, -t * 0.2);
            Fx.screen(sw, c, 40, 0.1f + t * 0.01f, 1f, 2, 0xFFF7B0);
        });
        Scheduler.later(42, () -> {
            Fx.sound(sw, u.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, 4f, 0.5f);
            Fx.sound(sw, u.blockPosition(), SoundEvents.GENERIC_EXPLODE, 4f, 0.4f);
            Fx.screen(sw, c, 250, 1f, 8f, 40, 0xFFFFFF);
            Fx.burst(sw, ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
            for (Mob m : Util.foes(sw, c, 26)) {
                Util.hurt(sw, u, m, 60f);
                Util.shove(m, c, 2.5, 0.8);
            }
            Util.loop(20, 1, t -> {
                double r = (t + 1) * 1.3;
                Fx.sphere(sw, Pal.CREAM, c, r, 120, 0);
                Fx.sphere(sw, ParticleTypes.END_ROD, c, r * 0.9, 60, t * 0.1);
                Fx.sphere(sw, Pal.DREAM, c, r * 0.8, 50, 0);
            });
        });
    }

    static void kaleidoscope(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.ILLUSIONER_CAST_SPELL, 2f, 1.5f);
        Util.loop(50, 2, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 mid = u.position().add(0, 1.5, 0);
            for (int k = 0; k < 6; k++) {
                double rot = k * Math.PI / 6 + t * 0.05;
                for (int i = 0; i < 20; i++) {
                    double a = i * Math.PI * 2 / 20;
                    double r = 3 + 2 * Math.sin(a * 4 + t * 0.1);
                    double x = Math.cos(rot) * Math.cos(a) * r;
                    double z = Math.sin(rot) * Math.cos(a) * r;
                    double y = Math.sin(a) * r * 0.7;
                    Fx.burst(sw, Pal.rainbow((float) (a / (Math.PI * 2) + t * 0.02 + k / 6.0)), mid.x + x, mid.y + y, mid.z + z, 1, 0, 0, 0, 0);
                }
            }
            if (t % 10 == 0) {
                for (Mob m : Util.foes(sw, mid, 10)) {
                    m.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false));
                }
            }
        });
    }

    static void lucidDream(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 2));
        u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1200, 2));
        u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1200, 1));
        u.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 1200, 1));
        u.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0, false, false));
        u.addEffect(new MobEffectInstance(MobEffects.JUMP, 1200, 1));
        u.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 1200, 1));
        Util.msg(u, "\u00a7d\u00a7oYou know you are dreaming.");
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_POWER_SELECT, 3f, 0.8f);
        Fx.screen(sw, u.position(), 40, 0.8f, 3f, 12, 0xF0E0FF);
        Util.loop(50, 1, t -> {
            Fx.spiral(sw, Pal.DREAM, u.position(), 1.5, 4, 3, 36, t * 0.3);
            Fx.spiral(sw, ParticleTypes.END_ROD, u.position(), 1.0, 4, 3, 24, -t * 0.3);
            Fx.ring(sw, Pal.LAVENDER, u.getX(), u.getY() + 0.2, u.getZ(), t * 0.12, 24);
        });
    }

    static void wildImagination(ServerLevel sw, Player u) {
        final int[] pool = {11, 12, 15, 35, 36, 41, 47, 49, 54, 56, 58, 59, 61, 65, 69, 70};
        for (int i = 0; i < 7; i++) {
            Scheduler.later(i * 30 + 1, () -> {
                if (Util.gone(sw, u)) return;
                Abilities.Ability pick = Abilities.ALL[pool[sw.random.nextInt(pool.length)]];
                Util.msg(u, "\u00a7d\u00a7o" + pick.name());
                try {
                    pick.run().cast(sw, u);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
        }
    }
}

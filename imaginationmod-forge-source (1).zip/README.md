# Imagination (Forge 1.20.1)

No items. **You** have the power. Press **G** or **B** to open the menu.

73 abilities across six **modes**. Your mode makes you glow, and other players see it.

| Mode      | Abilities | Look |
|-----------|-----------|------|
| Dream     | 9  | soft pink glow |
| Liminal   | 10 | sickly fluorescent-yellow glow + a **fever-dream tesseract** that changes colour and warps across your face |
| Creation  | 15 | mint glow |
| Reality   | 13 | blue-lavender glow |
| Nightmare | 9  | dark purple glow + a **3D shape on your head that morphs sphere -> pyramid -> cube** and hides your face |
| Wonder    | 17 | rainbow-cycling glow |

## Controls (all rebindable under Controls -> Imagination)
- **G or B**: open the menu. Tabs switch your mode. Click an ability to cast it. Hover for a description.
- **R**: cast your last pick again (random if you haven't picked one).
- Casting any ability also puts you in that ability's mode. "Aura off" in the menu turns the glow off.

## Multiplayer
Install the mod on the server and on every client. Everyone gets the same keys. Modes are synced, so everyone
sees everyone else's glow, tesseract face and nightmare head.

## Safety
- Built blocks (bridges, walls, domes, towers...) are temporary, only replace air, and are removed on a timer
  (and on server stop). Nothing in your world is destroyed.
- Attacks only hit hostile mobs. Players, pets, villagers and your imaginary friends are never targeted.

## Build
Push this folder to a GitHub repo -> **Actions** tab -> download the `imaginationmod-1.20.1-forge` artifact
(contains `imaginationmod-1.0.0.jar`). Or locally: JDK 17 + Gradle 8.8, `gradle build`.
Install on Minecraft 1.20.1 + Forge 47.x. No other mods needed.
